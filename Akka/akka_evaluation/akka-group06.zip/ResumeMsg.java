package com.lab.evaluation25;

public class ResumeMsg {

}
