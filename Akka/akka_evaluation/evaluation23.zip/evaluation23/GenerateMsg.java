package com.lab.evaluation23;

public class GenerateMsg {

}
