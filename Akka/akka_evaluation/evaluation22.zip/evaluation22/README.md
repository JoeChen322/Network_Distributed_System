# Evaluation lab - Akka

## Group number: XX

## Group members

- Student 1 
- Student 2
- Student 3

## Description of message flows

