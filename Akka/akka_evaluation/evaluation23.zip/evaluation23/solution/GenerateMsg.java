package com.lab.evaluation23.solution;

public class GenerateMsg {

}
