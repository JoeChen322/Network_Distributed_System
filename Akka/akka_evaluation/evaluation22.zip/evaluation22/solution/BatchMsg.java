package com.lab.evaluation22.solution;

public class BatchMsg {
	
	private boolean isOn;
	
	public BatchMsg(boolean isOn) {
		this.isOn = isOn;
	}

	public boolean isOn() {
		return isOn;
	}
}
