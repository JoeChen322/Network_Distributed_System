package com.lab.evaluation22;

public class BatchMsg {
	
	private boolean isOn;
	
	public BatchMsg(boolean isOn) {
		this.isOn = isOn;
	}

	public boolean isOn() {
		return isOn;
	}
}
