package com.lab.evaluation22.solution;

public class NotifyMsg {

	private String value;
	
	public NotifyMsg (String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
